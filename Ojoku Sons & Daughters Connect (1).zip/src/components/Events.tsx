import { Calendar, MapPin, Users, Clock, Bell, CheckCircle } from 'lucide-react';
import { useState } from 'react';

export function Events() {
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past'>('upcoming');

  const upcomingEvents: any[] = [];

  const pastEvents: any[] = [];

  return (
    <div className="min-h-full bg-[#FAF8F5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#8B4513] to-[#A0522D] text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <h2 className="mb-2">Events & Meetings</h2>
        <p className="text-white/80 mb-4">
          Stay connected with community gatherings
        </p>

        {/* Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`flex-1 py-2 px-4 rounded-xl transition-colors ${
              activeTab === 'upcoming'
                ? 'bg-white text-[#8B4513]'
                : 'bg-white/20 text-white'
            }`}
          >
            Upcoming
          </button>
          <button
            onClick={() => setActiveTab('past')}
            className={`flex-1 py-2 px-4 rounded-xl transition-colors ${
              activeTab === 'past'
                ? 'bg-white text-[#8B4513]'
                : 'bg-white/20 text-white'
            }`}
          >
            Past Events
          </button>
        </div>
      </div>

      {/* Upcoming Events */}
      {activeTab === 'upcoming' && (
        <div className="px-4 py-6">
          {upcomingEvents.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E8DCC8] text-center">
              <div className="text-[#A0826D] mb-2">No upcoming events</div>
              <p className="text-sm text-[#A0826D]">
                Event information will be posted here
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingEvents.map((event) => (
                <div
                  key={event.id}
                  className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="text-[#6B5644]">{event.title}</h4>
                        {event.registered && (
                          <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full flex items-center gap-1">
                            <CheckCircle size={12} />
                            Registered
                          </span>
                        )}
                      </div>
                      <span className="inline-block px-2 py-1 bg-[#FAF8F5] text-[#8B4513] text-xs rounded-full mb-2">
                        {event.category}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm text-[#6B5644]">
                      <Calendar size={16} className="text-[#A0826D]" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-[#6B5644]">
                      <Clock size={16} className="text-[#A0826D]" />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-[#6B5644]">
                      <MapPin size={16} className="text-[#A0826D]" />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-[#6B5644]">
                      <Users size={16} className="text-[#A0826D]" />
                      <span>{event.attendees} registered</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    {!event.registered ? (
                      <>
                        <button className="flex-1 py-2 bg-[#8B4513] text-white rounded-lg">
                          Register
                        </button>
                        <button className="px-4 py-2 border border-[#8B4513] text-[#8B4513] rounded-lg">
                          <Bell size={18} />
                        </button>
                      </>
                    ) : (
                      <button className="flex-1 py-2 border border-[#8B4513] text-[#8B4513] rounded-lg">
                        View Details
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Past Events */}
      {activeTab === 'past' && (
        <div className="px-4 py-6">
          {pastEvents.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E8DCC8] text-center">
              <div className="text-[#A0826D] mb-2">No past events</div>
              <p className="text-sm text-[#A0826D]">
                Past event records will appear here
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {pastEvents.map((event) => (
                <div
                  key={event.id}
                  className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]"
                >
                  <h4 className="text-[#6B5644] mb-2">{event.title}</h4>
                  
                  <div className="flex items-center gap-4 text-sm text-[#A0826D] mb-3">
                    <div className="flex items-center gap-1">
                      <Calendar size={14} />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users size={14} />
                      <span>{event.attendees} attended</span>
                    </div>
                  </div>

                  <p className="text-sm text-[#6B5644] mb-3">
                    {event.highlights}
                  </p>

                  <button className="w-full py-2 border border-[#8B4513] text-[#8B4513] rounded-lg">
                    View Photos & Videos
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}