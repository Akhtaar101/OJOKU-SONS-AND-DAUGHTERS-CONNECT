import { BookOpen, Users, Award, MapPin, ChevronRight } from 'lucide-react';

export function Heritage() {
  const sections = [
    {
      id: 1,
      title: 'Origin Story',
      description: 'Learn about the founding and history of Ojoku',
      icon: BookOpen,
      color: 'bg-[#8B4513]'
    },
    {
      id: 2,
      title: 'Past Leaders',
      description: 'Honoring those who led us through the years',
      icon: Users,
      color: 'bg-[#A0522D]'
    },
    {
      id: 3,
      title: 'Cultural Values',
      description: 'The principles that guide our community',
      icon: Award,
      color: 'bg-[#CD853F]'
    },
    {
      id: 4,
      title: 'Heroes & Legends',
      description: 'Celebrating our remarkable ancestors',
      icon: Award,
      color: 'bg-[#D2691E]'
    }
  ];

  const pastLeaders = [
    {
      name: 'Late Chief Okechukwu Ojoku',
      period: '1950 - 1975',
      achievement: 'Founded the first Ojoku community school'
    },
    {
      name: 'Late Elder Nneka Ojoku',
      period: '1975 - 1995',
      achievement: 'Established Ojoku welfare programs'
    },
    {
      name: 'Chief Chukwuemeka Ojoku',
      period: '1995 - 2015',
      achievement: 'Expanded Ojoku to international branches'
    }
  ];

  const culturalValues = [
    { value: 'Unity', description: 'We are stronger together as one community' },
    { value: 'Respect', description: 'Honoring our elders and traditions' },
    { value: 'Progress', description: 'Advancing while preserving our heritage' },
    { value: 'Integrity', description: 'Upholding honesty in all our dealings' }
  ];

  return (
    <div className="min-h-full bg-[#FAF8F5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#8B4513] to-[#A0522D] text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <h2 className="mb-2">History & Heritage</h2>
        <p className="text-white/80">
          Preserving our past, building our future
        </p>
      </div>

      {/* Quick Navigation */}
      <div className="px-4 py-6">
        <div className="grid grid-cols-2 gap-3 mb-6">
          {sections.map((section) => (
            <button
              key={section.id}
              className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8] text-left"
            >
              <div className={`${section.color} w-12 h-12 rounded-xl flex items-center justify-center mb-3`}>
                <section.icon size={24} className="text-white" />
              </div>
              <h4 className="text-[#6B5644] mb-1">{section.title}</h4>
              <p className="text-xs text-[#A0826D]">{section.description}</p>
            </button>
          ))}
        </div>

        {/* Origin Story */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#E8DCC8] mb-4">
          <div className="flex items-center gap-2 mb-3">
            <BookOpen size={20} className="text-[#8B4513]" />
            <h3 className="text-[#8B4513]">The Origin of Ojoku</h3>
          </div>
          <p className="text-[#6B5644] mb-3 leading-relaxed">
            Ojoku was founded centuries ago by brave settlers who sought to create a community 
            built on unity, respect, and cultural preservation. The name "Ojoku" means "shared 
            prosperity" in our native tongue, reflecting our ancestors' vision of a community 
            where all members thrive together.
          </p>
          <div className="flex items-center gap-2 text-sm text-[#A0826D]">
            <MapPin size={14} />
            <span>Southeastern Nigeria</span>
          </div>
        </div>

        {/* Past Leaders */}
        <div className="mb-4">
          <h3 className="text-[#8B4513] mb-3">Past Leaders</h3>
          <div className="space-y-3">
            {pastLeaders.map((leader, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]"
              >
                <div className="flex gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#CD853F] to-[#8B4513] flex items-center justify-center text-white flex-shrink-0">
                    {leader.name.split(' ')[1][0]}
                  </div>
                  <div className="flex-1">
                    <h4 className="text-[#6B5644] mb-1">{leader.name}</h4>
                    <p className="text-xs text-[#A0826D] mb-2">{leader.period}</p>
                    <p className="text-sm text-[#6B5644]">{leader.achievement}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cultural Values */}
        <div>
          <h3 className="text-[#8B4513] mb-3">Our Cultural Values</h3>
          <div className="space-y-3">
            {culturalValues.map((item, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="text-[#6B5644] mb-1">{item.value}</h4>
                    <p className="text-sm text-[#A0826D]">{item.description}</p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-[#8B4513] flex items-center justify-center text-white flex-shrink-0 ml-3">
                    {index + 1}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
