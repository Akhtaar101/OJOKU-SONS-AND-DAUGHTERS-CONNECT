import { Search, MapPin, Phone, Mail, Award, Filter, UserPlus } from 'lucide-react';
import { useState } from 'react';

interface MemberProfilesProps {
  onNavigate: (view: string) => void;
}

export function MemberProfiles({ onNavigate }: MemberProfilesProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterBranch, setFilterBranch] = useState('all');

  const members: any[] = [];

  const branches = ['all', 'Abuja', 'Lagos', 'UK', 'USA', 'Canada'];

  const filteredMembers = members.filter(member => {
    const matchesSearch = 
      member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesBranch = filterBranch === 'all' || member.branch === filterBranch;
    return matchesSearch && matchesBranch;
  });

  return (
    <div className="min-h-full bg-[#FAF8F5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#8B4513] to-[#A0522D] text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <h2 className="mb-4">Member Profiles</h2>
        <p className="text-white/80 mb-4">
          {members.length} verified members
        </p>
        
        {/* Search Bar */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8B4513]" size={20} />
          <input
            type="text"
            placeholder="Search members..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-xl bg-white text-[#6B5644] placeholder:text-[#A0826D]"
          />
        </div>

        {/* Branch Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {branches.map((branch) => (
            <button
              key={branch}
              onClick={() => setFilterBranch(branch)}
              className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-colors ${
                filterBranch === branch
                  ? 'bg-white text-[#8B4513]'
                  : 'bg-white/20 text-white'
              }`}
            >
              {branch === 'all' ? 'All Branches' : branch}
            </button>
          ))}
        </div>
      </div>

      {/* Register Button */}
      <div className="px-4 py-6">
        <button
          onClick={() => onNavigate('register')}
          className="w-full bg-[#8B4513] text-white py-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 mb-6"
        >
          <UserPlus size={20} />
          <span>Register New Member</span>
        </button>

        {/* Empty State or Members List */}
        {filteredMembers.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E8DCC8] text-center">
            <div className="w-16 h-16 bg-[#FAF8F5] rounded-full flex items-center justify-center mx-auto mb-4">
              <UserPlus size={32} className="text-[#A0826D]" />
            </div>
            <h3 className="text-[#6B5644] mb-2">No Members Yet</h3>
            <p className="text-sm text-[#A0826D] mb-4">
              Start building your community by registering members
            </p>
            <button
              onClick={() => onNavigate('register')}
              className="px-6 py-2 bg-[#8B4513] text-white rounded-lg"
            >
              Register First Member
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredMembers.map((member) => (
              <div
                key={member.id}
                className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]"
              >
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#CD853F] to-[#8B4513] flex items-center justify-center text-white text-xl">
                    {member.name.split(' ').map((n: string) => n[0]).join('')}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-[#6B5644]">{member.name}</h4>
                      {member.verified && (
                        <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      )}
                    </div>
                    <div className="text-sm text-[#A0826D] mb-1">{member.title}</div>
                    <div className="flex items-center gap-1 text-xs text-[#A0826D]">
                      <MapPin size={12} />
                      <span>{member.location}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div className="flex items-center gap-2 text-sm text-[#6B5644]">
                    <Phone size={14} className="text-[#A0826D]" />
                    <span className="text-xs">{member.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[#6B5644]">
                    <Award size={14} className="text-[#A0826D]" />
                    <span className="text-xs">{member.contributions} contributions</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-[#A0826D] mb-3">
                  <Mail size={12} />
                  <span>{member.email}</span>
                </div>

                <div className="pt-3 border-t border-[#E8DCC8] flex items-center justify-between">
                  <div className="text-xs text-[#A0826D]">
                    Member since {member.joinDate}
                  </div>
                  <button className="px-4 py-2 bg-[#8B4513] text-white rounded-lg text-xs">
                    View Profile
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}