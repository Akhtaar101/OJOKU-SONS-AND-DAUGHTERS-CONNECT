import { Bell, MapPin, TrendingUp, Heart, BookOpen, DollarSign, AlertCircle, Menu } from 'lucide-react';

interface HomeFeedProps {
  onNavigate: (view: string) => void;
}

export function HomeFeed({ onNavigate }: HomeFeedProps) {
  const announcements: any[] = [];

  const quickActions = [
    { icon: MapPin, label: 'Branches', view: 'branches', color: 'bg-[#CD853F]' },
    { icon: BookOpen, label: 'Heritage', view: 'heritage', color: 'bg-[#8B4513]' },
    { icon: DollarSign, label: 'Donate', view: 'donations', color: 'bg-[#A0522D]' },
    { icon: AlertCircle, label: 'Emergency', view: 'emergency', color: 'bg-[#D2691E]' }
  ];

  return (
    <div className="min-h-full bg-[#FAF8F5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#8B4513] to-[#A0522D] text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2>Welcome Back!</h2>
            <p className="text-white/80">Ojoku Community Portal</p>
          </div>
          <div className="relative">
            <Bell size={24} />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#D4AF37] rounded-full flex items-center justify-center text-xs">
              0
            </span>
          </div>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center">
            <div className="text-xl">0</div>
            <div className="text-xs text-white/80">Members</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center">
            <div className="text-xl">0</div>
            <div className="text-xs text-white/80">Branches</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center">
            <div className="text-xl">0</div>
            <div className="text-xs text-white/80">Events</div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-6">
        <h3 className="text-[#8B4513] mb-4">Quick Access</h3>
        <div className="grid grid-cols-4 gap-3">
          {quickActions.map((action, index) => (
            <button
              key={index}
              onClick={() => onNavigate(action.view)}
              className="flex flex-col items-center gap-2"
            >
              <div className={`${action.color} w-14 h-14 rounded-2xl flex items-center justify-center shadow-md`}>
                <action.icon size={24} className="text-white" />
              </div>
              <span className="text-xs text-[#6B5644] text-center">{action.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Announcements Feed */}
      <div className="px-4 pb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-[#8B4513]">Latest Updates</h3>
        </div>
        
        {announcements.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E8DCC8] text-center">
            <div className="text-[#A0826D] mb-2">No announcements yet</div>
            <p className="text-sm text-[#A0826D]">
              Community updates and news will appear here
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {announcements.map((announcement) => (
              <div
                key={announcement.id}
                className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="text-[#6B5644] mb-1">{announcement.title}</h4>
                    <p className="text-[#8B7355] text-sm mb-2">{announcement.content}</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between text-xs text-[#A0826D]">
                  <span>{announcement.author}</span>
                  <span>{announcement.time}</span>
                </div>
                
                <div className="flex items-center gap-4 mt-3 pt-3 border-t border-[#E8DCC8]">
                  <button className="flex items-center gap-1 text-[#8B4513]">
                    <Heart size={16} />
                    <span className="text-xs">Like</span>
                  </button>
                  <button className="flex items-center gap-1 text-[#8B4513]">
                    <TrendingUp size={16} />
                    <span className="text-xs">Share</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}