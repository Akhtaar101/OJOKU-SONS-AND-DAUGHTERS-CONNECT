import { MessageCircle, Users, Clock, ChevronRight, Send } from 'lucide-react';
import { useState } from 'react';

export function Forums() {
  const [selectedForum, setSelectedForum] = useState<number | null>(null);
  const [message, setMessage] = useState('');

  const forums: any[] = [];

  const messages = [
    {
      id: 1,
      sender: 'Chief Emeka',
      message: 'Good morning everyone! Hope you are all doing well.',
      time: '9:30 AM',
      isOwn: false
    },
    {
      id: 2,
      sender: 'You',
      message: 'Good morning Chief! All is well here.',
      time: '9:32 AM',
      isOwn: true
    },
    {
      id: 3,
      sender: 'Mrs. Ngozi',
      message: 'The meeting has been confirmed for next Saturday at 10 AM.',
      time: '9:45 AM',
      isOwn: false
    }
  ];

  if (selectedForum) {
    const forum = forums.find(f => f.id === selectedForum);
    
    return (
      <div className="flex flex-col h-full bg-[#FAF8F5]">
        {/* Chat Header */}
        <div className="bg-gradient-to-r from-[#8B4513] to-[#A0522D] text-white px-4 py-4 shadow-lg">
          <button
            onClick={() => setSelectedForum(null)}
            className="text-white mb-2 text-sm"
          >
            ← Back to Forums
          </button>
          <h3>{forum?.name}</h3>
          <div className="flex items-center gap-2 text-sm text-white/80 mt-1">
            <Users size={14} />
            <span>{forum?.members} members</span>
            <span>•</span>
            <span>{forum?.online} online</span>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-auto px-4 py-4 space-y-3">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.isOwn ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[75%] rounded-2xl px-4 py-3 ${
                  msg.isOwn
                    ? 'bg-[#8B4513] text-white'
                    : 'bg-white border border-[#E8DCC8] text-[#6B5644]'
                }`}
              >
                {!msg.isOwn && (
                  <div className="text-xs text-[#A0826D] mb-1">{msg.sender}</div>
                )}
                <p className="text-sm">{msg.message}</p>
                <div className={`text-xs mt-1 ${msg.isOwn ? 'text-white/70' : 'text-[#A0826D]'}`}>
                  {msg.time}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <div className="bg-white border-t border-[#E8DCC8] p-4">
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Type your message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="flex-1 px-4 py-3 rounded-full bg-[#FAF8F5] text-[#6B5644] border border-[#E8DCC8] placeholder:text-[#A0826D]"
            />
            <button className="w-12 h-12 rounded-full bg-[#8B4513] flex items-center justify-center text-white">
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full bg-[#FAF8F5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#8B4513] to-[#A0522D] text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <h2 className="mb-2">Forums & Discussions</h2>
        <p className="text-white/80">
          Connect with branches worldwide
        </p>
      </div>

      {/* Forums List */}
      <div className="px-4 py-6">
        {forums.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E8DCC8] text-center">
            <div className="text-[#A0826D] mb-2">No forums available yet</div>
            <p className="text-sm text-[#A0826D]">
              Branch forums will appear here once branches are created
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {forums.map((forum) => (
              <button
                key={forum.id}
                onClick={() => setSelectedForum(forum.id)}
                className="w-full bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8] text-left"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-[#6B5644]">{forum.name}</h4>
                      {forum.unread > 0 && (
                        <span className="px-2 py-0.5 bg-[#D4AF37] text-white text-xs rounded-full">
                          {forum.unread}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-[#A0826D] mb-2">{forum.lastMessage}</p>
                  </div>
                  <ChevronRight size={20} className="text-[#A0826D] flex-shrink-0 ml-2" />
                </div>
                
                <div className="flex items-center justify-between text-xs text-[#A0826D]">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <Users size={12} />
                      <span>{forum.members}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span>{forum.online} online</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock size={12} />
                    <span>{forum.lastMessageTime}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}