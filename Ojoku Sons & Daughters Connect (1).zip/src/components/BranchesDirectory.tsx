import { MapPin, Users, TrendingUp, ChevronRight, Search } from 'lucide-react';
import { useState } from 'react';

export function BranchesDirectory() {
  const [searchQuery, setSearchQuery] = useState('');

  const branches: any[] = [];

  const getPerformanceColor = (performance: number) => {
    if (performance >= 90) return 'text-green-600';
    if (performance >= 80) return 'text-[#D4AF37]';
    return 'text-orange-600';
  };

  const filteredBranches = branches.filter(branch =>
    branch.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    branch.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-full bg-[#FAF8F5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#8B4513] to-[#A0522D] text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <h2 className="mb-4">Branches Directory</h2>
        <p className="text-white/80 mb-4">
          {branches.length} branches worldwide
        </p>
        
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8B4513]" size={20} />
          <input
            type="text"
            placeholder="Search branches..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-xl bg-white text-[#6B5644] placeholder:text-[#A0826D]"
          />
        </div>
      </div>

      {/* Summary Cards */}
      <div className="px-4 py-6">
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="bg-white rounded-xl p-4 shadow-sm border border-[#E8DCC8]">
            <div className="text-2xl text-[#8B4513] mb-1">0</div>
            <div className="text-sm text-[#A0826D]">Total Branches</div>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm border border-[#E8DCC8]">
            <div className="text-2xl text-[#8B4513] mb-1">0</div>
            <div className="text-sm text-[#A0826D]">Total Members</div>
          </div>
        </div>

        {/* Branches List */}
        <h3 className="text-[#8B4513] mb-4">All Branches</h3>
        {filteredBranches.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E8DCC8] text-center">
            <div className="text-[#A0826D] mb-2">No branches registered yet</div>
            <p className="text-sm text-[#A0826D]">
              Branch information will appear here once registered
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredBranches.map((branch) => (
              <div
                key={branch.id}
                className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h4 className="text-[#6B5644] mb-1">{branch.name}</h4>
                    <div className="flex items-center gap-1 text-[#A0826D] text-sm mb-2">
                      <MapPin size={14} />
                      <span>{branch.location}</span>
                    </div>
                  </div>
                  <ChevronRight size={20} className="text-[#A0826D]" />
                </div>
                
                <div className="grid grid-cols-3 gap-3 mb-3">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 text-[#8B4513] mb-1">
                      <Users size={16} />
                      <span>{branch.members}</span>
                    </div>
                    <div className="text-xs text-[#A0826D]">Members</div>
                  </div>
                  
                  <div className="text-center">
                    <div className={`flex items-center justify-center gap-1 mb-1 ${getPerformanceColor(branch.performance)}`}>
                      <TrendingUp size={16} />
                      <span>{branch.performance}%</span>
                    </div>
                    <div className="text-xs text-[#A0826D]">Performance</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-[#8B4513] mb-1">
                      {branch.status}
                    </div>
                    <div className="text-xs text-[#A0826D]">Status</div>
                  </div>
                </div>
                
                <div className="pt-3 border-t border-[#E8DCC8]">
                  <div className="text-xs text-[#A0826D]">Branch Leader</div>
                  <div className="text-sm text-[#6B5644]">{branch.leader}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}