import { Image as ImageIcon, Video, Calendar, Download, Heart } from 'lucide-react';
import { useState } from 'react';

export function MediaGallery() {
  const [activeTab, setActiveTab] = useState<'photos' | 'videos'>('photos');

  const photos: any[] = [];

  const videos: any[] = [];

  return (
    <div className="min-h-full bg-[#FAF8F5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#8B4513] to-[#A0522D] text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <h2 className="mb-2">Media Gallery</h2>
        <p className="text-white/80 mb-4">
          Preserving our heritage through memories
        </p>

        {/* Tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('photos')}
            className={`flex-1 py-2 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors ${
              activeTab === 'photos'
                ? 'bg-white text-[#8B4513]'
                : 'bg-white/20 text-white'
            }`}
          >
            <ImageIcon size={18} />
            <span>Photos</span>
          </button>
          <button
            onClick={() => setActiveTab('videos')}
            className={`flex-1 py-2 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors ${
              activeTab === 'videos'
                ? 'bg-white text-[#8B4513]'
                : 'bg-white/20 text-white'
            }`}
          >
            <Video size={18} />
            <span>Videos</span>
          </button>
        </div>
      </div>

      {/* Photos Grid */}
      {activeTab === 'photos' && (
        <div className="px-4 py-6">
          {photos.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E8DCC8] text-center">
              <div className="text-[#A0826D] mb-2">No photos yet</div>
              <p className="text-sm text-[#A0826D]">
                Community photos and images will appear here
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {photos.map((photo) => (
                <div
                  key={photo.id}
                  className="bg-white rounded-2xl overflow-hidden shadow-sm border border-[#E8DCC8]"
                >
                  <div className="aspect-square bg-gradient-to-br from-[#CD853F] to-[#8B4513] flex items-center justify-center text-white">
                    <ImageIcon size={48} opacity={0.3} />
                  </div>
                  <div className="p-3">
                    <h4 className="text-sm text-[#6B5644] mb-1 line-clamp-2">
                      {photo.title}
                    </h4>
                    <div className="flex items-center justify-between text-xs text-[#A0826D] mb-2">
                      <div className="flex items-center gap-1">
                        <Calendar size={10} />
                        <span>{photo.date}</span>
                      </div>
                      <span className="px-2 py-0.5 bg-[#FAF8F5] rounded-full text-[10px]">
                        {photo.category}
                      </span>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-[#E8DCC8]">
                      <button className="flex items-center gap-1 text-[#8B4513]">
                        <Heart size={14} />
                        <span className="text-xs">{photo.likes}</span>
                      </button>
                      <button className="text-[#8B4513]">
                        <Download size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Videos List */}
      {activeTab === 'videos' && (
        <div className="px-4 py-6">
          {videos.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E8DCC8] text-center">
              <div className="text-[#A0826D] mb-2">No videos yet</div>
              <p className="text-sm text-[#A0826D]">
                Community videos will appear here
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {videos.map((video) => (
                <div
                  key={video.id}
                  className="bg-white rounded-2xl overflow-hidden shadow-sm border border-[#E8DCC8]"
                >
                  <div className="aspect-video bg-gradient-to-br from-[#CD853F] to-[#8B4513] flex items-center justify-center text-white relative">
                    <Video size={48} opacity={0.3} />
                    <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                      {video.duration}
                    </div>
                  </div>
                  <div className="p-4">
                    <h4 className="text-[#6B5644] mb-2">{video.title}</h4>
                    <div className="flex items-center justify-between text-xs text-[#A0826D]">
                      <div className="flex items-center gap-1">
                        <Calendar size={12} />
                        <span>{video.date}</span>
                      </div>
                      <span>{video.views.toLocaleString()} views</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}