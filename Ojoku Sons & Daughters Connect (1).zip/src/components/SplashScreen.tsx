export function SplashScreen() {
  return (
    <div className="h-screen bg-gradient-to-br from-[#8B4513] via-[#A0522D] to-[#CD853F] flex flex-col items-center justify-center relative overflow-hidden">
      {/* Traditional Pattern Overlay */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.3) 10px, rgba(255,255,255,0.3) 20px)`
        }}
      />
      
      {/* Emblem Circle */}
      <div className="relative z-10 flex flex-col items-center">
        <div className="w-32 h-32 rounded-full bg-white/90 shadow-2xl flex items-center justify-center mb-6 border-4 border-[#D4AF37]">
          <div className="text-5xl">🏛️</div>
        </div>
        
        <h1 className="text-white text-center px-6 mb-2">
          Ojoku Sons & Daughters Connect
        </h1>
        
        <p className="text-white/80 text-center px-6">
          United in Heritage, Connected Worldwide
        </p>
        
        {/* Loading Animation */}
        <div className="mt-8 flex gap-2">
          <div className="w-2 h-2 rounded-full bg-white animate-bounce" style={{ animationDelay: '0ms' }} />
          <div className="w-2 h-2 rounded-full bg-white animate-bounce" style={{ animationDelay: '150ms' }} />
          <div className="w-2 h-2 rounded-full bg-white animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
      </div>
      
      {/* Bottom Decoration */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#D4AF37] via-white to-[#D4AF37]" />
    </div>
  );
}
