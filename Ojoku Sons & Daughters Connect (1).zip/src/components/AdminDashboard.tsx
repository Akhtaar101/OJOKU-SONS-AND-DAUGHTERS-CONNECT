import { Settings, Users, MessageSquare, TrendingUp, FileText, Bell, Activity, PlusCircle } from 'lucide-react';

export function AdminDashboard() {
  const stats = [
    { label: 'Total Members', value: '0', change: '', icon: Users, color: 'bg-blue-500' },
    { label: 'Active Branches', value: '0', change: '', icon: Activity, color: 'bg-green-500' },
    { label: 'Pending Approvals', value: '0', change: '', icon: FileText, color: 'bg-orange-500' },
    { label: 'Monthly Donations', value: '₦0', change: '', icon: TrendingUp, color: 'bg-purple-500' }
  ];

  const quickActions = [
    { icon: Bell, label: 'Post Announcement', color: 'bg-[#8B4513]' },
    { icon: Users, label: 'Manage Members', color: 'bg-[#A0522D]' },
    { icon: FileText, label: 'Review Applications', color: 'bg-[#CD853F]' },
    { icon: MessageSquare, label: 'Moderate Forums', color: 'bg-[#D2691E]' }
  ];

  const recentActivities: any[] = [];

  const branchPerformance: any[] = [];

  return (
    <div className="min-h-full bg-[#FAF8F5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#8B4513] to-[#A0522D] text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="mb-1">Admin Dashboard</h2>
            <p className="text-white/80">Manage community operations</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
            <Settings size={20} />
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
              <div className="flex items-center justify-between mb-1">
                <stat.icon size={16} />
                {stat.change && (
                  <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">
                    {stat.change}
                  </span>
                )}
              </div>
              <div className="text-xl mb-1">{stat.value}</div>
              <div className="text-xs text-white/80">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-6">
        <h3 className="text-[#8B4513] mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-3 mb-6">
          {quickActions.map((action, index) => (
            <button
              key={index}
              className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8] flex flex-col items-center text-center"
            >
              <div className={`${action.color} w-12 h-12 rounded-xl flex items-center justify-center mb-2`}>
                <action.icon size={24} className="text-white" />
              </div>
              <span className="text-sm text-[#6B5644]">{action.label}</span>
            </button>
          ))}
        </div>

        {/* Create New Announcement */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8] mb-6">
          <h4 className="text-[#6B5644] mb-3">Create Announcement</h4>
          <textarea
            placeholder="What would you like to share with the community?"
            className="w-full px-4 py-3 bg-[#FAF8F5] rounded-xl text-[#6B5644] placeholder:text-[#A0826D] mb-3 min-h-[100px]"
          />
          <div className="flex gap-2">
            <button className="flex-1 py-2 bg-[#8B4513] text-white rounded-lg flex items-center justify-center gap-2">
              <PlusCircle size={18} />
              <span>Post Announcement</span>
            </button>
            <button className="px-4 py-2 border border-[#8B4513] text-[#8B4513] rounded-lg">
              Schedule
            </button>
          </div>
        </div>

        {/* Branch Performance */}
        {branchPerformance.length > 0 && (
          <div className="mb-6">
            <h3 className="text-[#8B4513] mb-4">Branch Performance</h3>
            <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]">
              <div className="space-y-3">
                {branchPerformance.map((branch, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="w-8 h-8 rounded-full bg-[#FAF8F5] flex items-center justify-center text-[#8B4513] text-sm">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="text-[#6B5644] mb-1">{branch.branch}</div>
                        <div className="h-1.5 bg-[#E8DCC8] rounded-full overflow-hidden">
                          <div
                            className="h-full bg-[#8B4513] rounded-full"
                            style={{ width: `${branch.score}%` }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="ml-3 text-right">
                      <div className="text-[#8B4513]">{branch.score}%</div>
                      <div className={`text-xs ${
                        branch.trend === 'up' ? 'text-green-600' :
                        branch.trend === 'down' ? 'text-red-600' :
                        'text-gray-600'
                      }`}>
                        {branch.trend === 'up' ? '↑' : branch.trend === 'down' ? '↓' : '→'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Recent Activity */}
        <div>
          <h3 className="text-[#8B4513] mb-4">Recent Activity</h3>
          {recentActivities.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E8DCC8] text-center">
              <div className="text-[#A0826D] mb-2">No recent activity</div>
              <p className="text-sm text-[#A0826D]">
                Activity logs will appear here
              </p>
            </div>
          ) : (
            <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]">
              <div className="space-y-3">
                {recentActivities.map((activity, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 pb-3 border-b border-[#E8DCC8] last:border-0 last:pb-0"
                  >
                    <div className="w-8 h-8 rounded-full bg-[#FAF8F5] flex items-center justify-center flex-shrink-0">
                      <Activity size={16} className="text-[#8B4513]" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-[#6B5644] mb-0.5">{activity.action}</div>
                      <div className="text-xs text-[#A0826D]">
                        {activity.user} • {activity.time}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}