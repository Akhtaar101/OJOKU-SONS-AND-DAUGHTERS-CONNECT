import { DollarSign, TrendingUp, Target, Users, CheckCircle, Clock } from 'lucide-react';

export function Donations() {
  const projects: any[] = [];

  const recentContributions: any[] = [];

  const formatCurrency = (amount: number) => {
    return `₦${amount.toLocaleString()}`;
  };

  const getProgressPercentage = (raised: number, target: number) => {
    return Math.min((raised / target) * 100, 100);
  };

  return (
    <div className="min-h-full bg-[#FAF8F5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#8B4513] to-[#A0522D] text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <h2 className="mb-2">Donations & Projects</h2>
        <p className="text-white/80 mb-4">
          Building our community together
        </p>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
            <div className="text-2xl mb-1">₦0</div>
            <div className="text-xs text-white/80">Total Raised</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
            <div className="text-2xl mb-1">0</div>
            <div className="text-xs text-white/80">Contributors</div>
          </div>
        </div>
      </div>

      {/* Active Projects */}
      <div className="px-4 py-6">
        <h3 className="text-[#8B4513] mb-4">Active Projects</h3>
        {projects.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-[#E8DCC8] text-center mb-6">
            <div className="text-[#A0826D] mb-2">No active projects</div>
            <p className="text-sm text-[#A0826D]">
              Community projects will be listed here
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {projects.map((project) => {
              const progress = getProgressPercentage(project.raised, project.target);
              
              return (
                <div
                  key={project.id}
                  className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="text-[#6B5644] mb-1">{project.title}</h4>
                      <p className="text-sm text-[#A0826D] mb-2">{project.description}</p>
                    </div>
                    {project.status === 'completed' && (
                      <CheckCircle size={20} className="text-green-500 flex-shrink-0 ml-2" />
                    )}
                  </div>

                  {/* Progress Bar */}
                  <div className="mb-3">
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-[#8B4513]">
                        {formatCurrency(project.raised)}
                      </span>
                      <span className="text-[#A0826D]">
                        {formatCurrency(project.target)}
                      </span>
                    </div>
                    <div className="h-2 bg-[#E8DCC8] rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${
                          project.status === 'completed' ? 'bg-green-500' : 'bg-[#8B4513]'
                        }`}
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    <div className="text-xs text-[#A0826D] text-right mt-1">
                      {progress.toFixed(0)}% funded
                    </div>
                  </div>

                  {/* Project Stats */}
                  <div className="grid grid-cols-2 gap-3 mb-3">
                    <div className="flex items-center gap-2 text-sm text-[#6B5644]">
                      <Users size={16} className="text-[#A0826D]" />
                      <span>{project.contributors} contributors</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-[#6B5644]">
                      <Clock size={16} className="text-[#A0826D]" />
                      <span>{project.deadline}</span>
                    </div>
                  </div>

                  {project.status === 'active' && (
                    <button className="w-full py-2 bg-[#8B4513] text-white rounded-lg">
                      Contribute Now
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Recent Contributions */}
        {recentContributions.length > 0 && (
          <div className="mt-6">
            <h3 className="text-[#8B4513] mb-4">Recent Contributions</h3>
            <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]">
              <div className="space-y-3">
                {recentContributions.map((contribution, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between pb-3 border-b border-[#E8DCC8] last:border-0 last:pb-0"
                  >
                    <div className="flex-1">
                      <div className="text-[#6B5644] mb-1">{contribution.name}</div>
                      <div className="text-xs text-[#A0826D]">{contribution.project}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-[#8B4513]">
                        {formatCurrency(contribution.amount)}
                      </div>
                      <div className="text-xs text-[#A0826D]">{contribution.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Transparency Notice */}
        <div className="mt-6 bg-gradient-to-r from-[#8B4513] to-[#A0522D] rounded-2xl p-4 text-white">
          <div className="flex items-center gap-2 mb-2">
            <Target size={20} />
            <h4>Transparency Promise</h4>
          </div>
          <p className="text-sm text-white/80">
            All donations are tracked and reported. Project progress and fund utilization 
            reports are published monthly for community transparency.
          </p>
        </div>
      </div>
    </div>
  );
}