import { useState } from 'react';
import { User, Mail, Phone, MapPin, Home, Check } from 'lucide-react';

export function MemberRegistration() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    location: '',
    branch: '',
    address: '',
    dateOfBirth: '',
    occupation: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const branches = [
    'Select Branch',
    'Abuja Branch',
    'Lagos Branch',
    'Port Harcourt Branch',
    'UK Diaspora',
    'USA Diaspora',
    'Canada Branch',
    'Other (Please specify)'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would send the data to your backend/database
    console.log('Registration submitted:', formData);
    setSubmitted(true);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (submitted) {
    return (
      <div className="min-h-full bg-[#FAF8F5] flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl p-8 shadow-lg border border-[#E8DCC8] text-center max-w-md">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check size={40} className="text-green-600" />
          </div>
          <h3 className="text-[#6B5644] mb-2">Registration Submitted!</h3>
          <p className="text-[#A0826D] mb-6">
            Thank you for registering. Your application is under review and you will be contacted once verified.
          </p>
          <button
            onClick={() => setSubmitted(false)}
            className="w-full py-3 bg-[#8B4513] text-white rounded-lg"
          >
            Register Another Member
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full bg-[#FAF8F5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#8B4513] to-[#A0522D] text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <h2 className="mb-2">Member Registration</h2>
        <p className="text-white/80">
          Join the Ojoku community worldwide
        </p>
      </div>

      {/* Registration Form */}
      <div className="px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Full Name */}
          <div>
            <label className="block text-[#6B5644] mb-2 text-sm">
              Full Name <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-[#A0826D]" size={20} />
              <input
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
                required
                placeholder="Enter your full name"
                className="w-full pl-12 pr-4 py-3 rounded-xl bg-white border border-[#E8DCC8] text-[#6B5644] placeholder:text-[#A0826D]"
              />
            </div>
          </div>

          {/* Email */}
          <div>
            <label className="block text-[#6B5644] mb-2 text-sm">
              Email Address <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-[#A0826D]" size={20} />
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="your.email@example.com"
                className="w-full pl-12 pr-4 py-3 rounded-xl bg-white border border-[#E8DCC8] text-[#6B5644] placeholder:text-[#A0826D]"
              />
            </div>
          </div>

          {/* Phone */}
          <div>
            <label className="block text-[#6B5644] mb-2 text-sm">
              Phone Number <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-[#A0826D]" size={20} />
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
                placeholder="+234 XXX XXX XXXX"
                className="w-full pl-12 pr-4 py-3 rounded-xl bg-white border border-[#E8DCC8] text-[#6B5644] placeholder:text-[#A0826D]"
              />
            </div>
          </div>

          {/* Date of Birth */}
          <div>
            <label className="block text-[#6B5644] mb-2 text-sm">
              Date of Birth <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              name="dateOfBirth"
              value={formData.dateOfBirth}
              onChange={handleChange}
              required
              className="w-full px-4 py-3 rounded-xl bg-white border border-[#E8DCC8] text-[#6B5644]"
            />
          </div>

          {/* Branch Selection */}
          <div>
            <label className="block text-[#6B5644] mb-2 text-sm">
              Preferred Branch <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-[#A0826D]" size={20} />
              <select
                name="branch"
                value={formData.branch}
                onChange={handleChange}
                required
                className="w-full pl-12 pr-4 py-3 rounded-xl bg-white border border-[#E8DCC8] text-[#6B5644] appearance-none"
              >
                {branches.map((branch) => (
                  <option key={branch} value={branch}>
                    {branch}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Current Location */}
          <div>
            <label className="block text-[#6B5644] mb-2 text-sm">
              Current Location <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="location"
              value={formData.location}
              onChange={handleChange}
              required
              placeholder="City, Country"
              className="w-full px-4 py-3 rounded-xl bg-white border border-[#E8DCC8] text-[#6B5644] placeholder:text-[#A0826D]"
            />
          </div>

          {/* Occupation */}
          <div>
            <label className="block text-[#6B5644] mb-2 text-sm">
              Occupation
            </label>
            <input
              type="text"
              name="occupation"
              value={formData.occupation}
              onChange={handleChange}
              placeholder="Your profession"
              className="w-full px-4 py-3 rounded-xl bg-white border border-[#E8DCC8] text-[#6B5644] placeholder:text-[#A0826D]"
            />
          </div>

          {/* Address */}
          <div>
            <label className="block text-[#6B5644] mb-2 text-sm">
              Home Address
            </label>
            <div className="relative">
              <Home className="absolute left-3 top-3 text-[#A0826D]" size={20} />
              <textarea
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="Enter your full address"
                rows={3}
                className="w-full pl-12 pr-4 py-3 rounded-xl bg-white border border-[#E8DCC8] text-[#6B5644] placeholder:text-[#A0826D]"
              />
            </div>
          </div>

          {/* Terms & Conditions */}
          <div className="bg-[#FAF8F5] rounded-xl p-4 border border-[#E8DCC8]">
            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                required
                className="mt-1 w-4 h-4 rounded border-[#A0826D] text-[#8B4513]"
              />
              <span className="text-sm text-[#6B5644]">
                I agree to the terms and conditions and confirm that the information provided is accurate
              </span>
            </label>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-4 bg-[#8B4513] text-white rounded-xl shadow-lg"
          >
            Submit Registration
          </button>
        </form>

        {/* Info Notice */}
        <div className="mt-6 bg-gradient-to-r from-[#8B4513] to-[#A0522D] rounded-2xl p-4 text-white">
          <h4 className="mb-2">Verification Process</h4>
          <p className="text-sm text-white/80">
            All registrations are reviewed by branch leaders to verify authenticity. 
            You will receive a confirmation email once your membership is approved.
          </p>
        </div>
      </div>
    </div>
  );
}
