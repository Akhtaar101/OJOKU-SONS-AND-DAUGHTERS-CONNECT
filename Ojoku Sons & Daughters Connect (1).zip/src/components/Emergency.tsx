import { AlertCircle, Phone, MapPin, Heart, Users, Clock } from 'lucide-react';

export function Emergency() {
  const emergencyContacts = [
    {
      name: 'Emergency Coordinator',
      role: 'Chief Response Officer',
      phone: '+234 800 OJOKU 911',
      available: '24/7'
    },
    {
      name: 'Medical Emergency',
      role: 'Healthcare Support',
      phone: '+234 800 OJOKU MED',
      available: '24/7'
    },
    {
      name: 'Welfare Officer',
      role: 'Financial Assistance',
      phone: '+234 803 XXX XXXX',
      available: 'Mon-Fri 9AM-5PM'
    },
    {
      name: 'Branch Coordinators',
      role: 'Local Support',
      phone: 'See Branch Directory',
      available: 'Varies by branch'
    }
  ];

  const recentRequests = [
    {
      id: 1,
      type: 'Medical',
      requester: 'Member from Lagos',
      status: 'Resolved',
      date: '2 days ago',
      support: '₦150,000 provided'
    },
    {
      id: 2,
      type: 'Financial',
      requester: 'Member from Abuja',
      status: 'In Progress',
      date: '5 days ago',
      support: 'Processing'
    },
    {
      id: 3,
      type: 'Emergency',
      requester: 'Member from PH',
      status: 'Resolved',
      date: '1 week ago',
      support: 'Support provided'
    }
  ];

  const welfarePrograms = [
    {
      title: 'Medical Emergency Fund',
      description: 'Quick financial support for medical emergencies',
      eligibility: 'All verified members'
    },
    {
      title: 'Bereavement Support',
      description: 'Assistance during loss of loved ones',
      eligibility: 'All verified members'
    },
    {
      title: 'Natural Disaster Relief',
      description: 'Support for members affected by natural disasters',
      eligibility: 'Affected members'
    },
    {
      title: 'Education Crisis Fund',
      description: 'Emergency support for children\'s education',
      eligibility: 'Members with school-age children'
    }
  ];

  return (
    <div className="min-h-full bg-[#FAF8F5]">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#D2691E] to-[#A0522D] text-white px-4 py-6 rounded-b-3xl shadow-lg">
        <div className="flex items-center gap-2 mb-2">
          <AlertCircle size={28} />
          <h2>Emergency Help</h2>
        </div>
        <p className="text-white/80">
          We are here to support you in times of need
        </p>
      </div>

      {/* Quick Action Button */}
      <div className="px-4 py-6">
        <button className="w-full bg-red-600 text-white py-4 rounded-2xl shadow-lg flex items-center justify-center gap-2 mb-6">
          <AlertCircle size={24} />
          <span className="text-lg">Request Emergency Assistance</span>
        </button>

        {/* Emergency Contacts */}
        <div className="mb-6">
          <h3 className="text-[#8B4513] mb-4">Emergency Contacts</h3>
          <div className="space-y-3">
            {emergencyContacts.map((contact, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="text-[#6B5644] mb-1">{contact.name}</h4>
                    <p className="text-sm text-[#A0826D] mb-2">{contact.role}</p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-[#8B4513] flex items-center justify-center flex-shrink-0">
                    <Phone size={18} className="text-white" />
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="text-[#8B4513]">{contact.phone}</div>
                  <div className="flex items-center gap-1 text-xs text-[#A0826D]">
                    <Clock size={12} />
                    <span>{contact.available}</span>
                  </div>
                </div>
                
                <button className="w-full mt-3 py-2 bg-[#8B4513] text-white rounded-lg flex items-center justify-center gap-2">
                  <Phone size={16} />
                  <span>Call Now</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Welfare Programs */}
        <div className="mb-6">
          <h3 className="text-[#8B4513] mb-4">Welfare Programs</h3>
          <div className="space-y-3">
            {welfarePrograms.map((program, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]"
              >
                <div className="flex items-start gap-3 mb-2">
                  <div className="w-10 h-10 rounded-full bg-[#FAF8F5] flex items-center justify-center flex-shrink-0 text-[#8B4513]">
                    <Heart size={20} />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-[#6B5644] mb-1">{program.title}</h4>
                    <p className="text-sm text-[#A0826D] mb-2">{program.description}</p>
                    <div className="text-xs text-[#8B4513]">
                      Eligibility: {program.eligibility}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Support Requests */}
        <div>
          <h3 className="text-[#8B4513] mb-4">Recent Support Cases</h3>
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#E8DCC8]">
            <div className="space-y-3">
              {recentRequests.map((request) => (
                <div
                  key={request.id}
                  className="pb-3 border-b border-[#E8DCC8] last:border-0 last:pb-0"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[#6B5644]">{request.type} Support</span>
                        <span className={`px-2 py-0.5 rounded-full text-xs ${
                          request.status === 'Resolved'
                            ? 'bg-green-100 text-green-700'
                            : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {request.status}
                        </span>
                      </div>
                      <p className="text-sm text-[#A0826D] mb-1">{request.requester}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs text-[#A0826D]">
                    <span>{request.date}</span>
                    <span className="text-[#8B4513]">{request.support}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Support Notice */}
        <div className="mt-6 bg-gradient-to-r from-[#8B4513] to-[#A0522D] rounded-2xl p-4 text-white">
          <div className="flex items-center gap-2 mb-2">
            <Users size={20} />
            <h4>Community Support</h4>
          </div>
          <p className="text-sm text-white/80">
            All welfare requests are treated with confidentiality and dignity. 
            Our community is committed to supporting members in times of genuine need.
          </p>
        </div>
      </div>
    </div>
  );
}
