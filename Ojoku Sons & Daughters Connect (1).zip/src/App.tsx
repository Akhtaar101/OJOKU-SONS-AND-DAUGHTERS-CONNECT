import { useState, useEffect } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { HomeFeed } from './components/HomeFeed';
import { BranchesDirectory } from './components/BranchesDirectory';
import { MemberProfiles } from './components/MemberProfiles';
import { MemberRegistration } from './components/MemberRegistration';
import { Forums } from './components/Forums';
import { MediaGallery } from './components/MediaGallery';
import { Heritage } from './components/Heritage';
import { Events } from './components/Events';
import { Donations } from './components/Donations';
import { Emergency } from './components/Emergency';
import { AdminDashboard } from './components/AdminDashboard';
import { Home, Users, MessageCircle, Image, Calendar, DollarSign, AlertCircle, Settings } from 'lucide-react';

type View = 'splash' | 'home' | 'branches' | 'members' | 'register' | 'forums' | 'gallery' | 'heritage' | 'events' | 'donations' | 'emergency' | 'admin';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('splash');
  const [isAdmin, setIsAdmin] = useState(true); // Mock admin status

  useEffect(() => {
    if (currentView === 'splash') {
      const timer = setTimeout(() => {
        setCurrentView('home');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [currentView]);

  if (currentView === 'splash') {
    return <SplashScreen />;
  }

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return <HomeFeed onNavigate={setCurrentView} />;
      case 'branches':
        return <BranchesDirectory />;
      case 'members':
        return <MemberProfiles onNavigate={setCurrentView} />;
      case 'register':
        return <MemberRegistration />;
      case 'forums':
        return <Forums />;
      case 'gallery':
        return <MediaGallery />;
      case 'heritage':
        return <Heritage />;
      case 'events':
        return <Events />;
      case 'donations':
        return <Donations />;
      case 'emergency':
        return <Emergency />;
      case 'admin':
        return <AdminDashboard />;
      default:
        return <HomeFeed onNavigate={setCurrentView} />;
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#FAF8F5] max-w-md mx-auto">
      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {renderView()}
      </div>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-[#D4C5B0] shadow-lg">
        <div className="flex justify-around items-center h-16">
          <button
            onClick={() => setCurrentView('home')}
            className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-colors ${
              currentView === 'home' ? 'text-[#8B4513]' : 'text-[#A0826D]'
            }`}
          >
            <Home size={20} />
            <span className="text-xs">Home</span>
          </button>
          
          <button
            onClick={() => setCurrentView('members')}
            className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-colors ${
              currentView === 'members' || currentView === 'register' ? 'text-[#8B4513]' : 'text-[#A0826D]'
            }`}
          >
            <Users size={20} />
            <span className="text-xs">Members</span>
          </button>
          
          <button
            onClick={() => setCurrentView('forums')}
            className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-colors ${
              currentView === 'forums' ? 'text-[#8B4513]' : 'text-[#A0826D]'
            }`}
          >
            <MessageCircle size={20} />
            <span className="text-xs">Forums</span>
          </button>
          
          <button
            onClick={() => setCurrentView('events')}
            className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-colors ${
              currentView === 'events' ? 'text-[#8B4513]' : 'text-[#A0826D]'
            }`}
          >
            <Calendar size={20} />
            <span className="text-xs">Events</span>
          </button>
          
          {isAdmin && (
            <button
              onClick={() => setCurrentView('admin')}
              className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-colors ${
                currentView === 'admin' ? 'text-[#8B4513]' : 'text-[#A0826D]'
              }`}
            >
              <Settings size={20} />
              <span className="text-xs">Admin</span>
            </button>
          )}
        </div>
      </nav>
    </div>
  );
}